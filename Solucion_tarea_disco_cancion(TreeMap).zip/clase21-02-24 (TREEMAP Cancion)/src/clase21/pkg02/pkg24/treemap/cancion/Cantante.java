package clase21.pkg02.pkg24.treemap.cancion;

public class Cantante {

    public String cantante;
    public Disco d;
    public Cancion c;
    public static Integer k = 0;

    public Cantante(String cantante, Disco d, Cancion c) {
        this.cantante = cantante;
        this.d = d;
        this.c = c;
        d.cancion.put(k, this);
        c.disco.put(k, this);
        k++;
    }

}
