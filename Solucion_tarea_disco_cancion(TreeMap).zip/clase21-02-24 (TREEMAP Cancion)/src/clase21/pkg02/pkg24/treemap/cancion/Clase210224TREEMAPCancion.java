package clase21.pkg02.pkg24.treemap.cancion;

public class Clase210224TREEMAPCancion {

    public static void main(String[] args) {

        Disco d1 = new Disco("Fulgor");
        Disco d2 = new Disco("Buena Comida");

        Cancion c1 = new Cancion("La vida es asi");
        Cancion c2 = new Cancion("Helado");

        Cantante a1 = new Cantante("Pablo Alboran", d1, c1);
        Cantante a2 = new Cantante("Melinda", d2, c1);
        Cantante a3 = new Cantante("Pablo Motos", d1, c2);
        
        d1.mostrar();
        System.out.println("\n ----------------------- \n");
        c1.mostrar();
        
    }

}
