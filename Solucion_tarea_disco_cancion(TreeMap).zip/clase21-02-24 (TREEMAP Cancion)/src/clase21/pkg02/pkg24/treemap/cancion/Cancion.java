package clase21.pkg02.pkg24.treemap.cancion;

import java.util.TreeMap;

public class Cancion {

    public String cancion;
    public TreeMap<Integer, Cantante> disco;

    public Cancion(String cancion) {
        this.cancion = cancion;
        this.disco = new TreeMap<>();
    }

    public void mostrar() {
        System.out.println("Discos de la cancion '"+this.cancion+"' :");
        disco.forEach((k, v) -> {System.out.println(k + " : " + v.cantante + " | " + v.d.disco);});
    }
}
