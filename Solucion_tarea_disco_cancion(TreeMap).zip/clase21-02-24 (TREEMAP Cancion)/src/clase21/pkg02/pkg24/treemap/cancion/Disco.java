package clase21.pkg02.pkg24.treemap.cancion;

import java.util.TreeMap;

public class Disco {
    
    public String disco;
    public TreeMap<Integer, Cantante> cancion;

    public Disco(String disco) {
        this.disco = disco;
        this.cancion = new TreeMap<>();
    }
    
    public void mostrar(){
        System.out.println("Canciones del disco '"+this.disco+"' :");
        cancion.forEach((k,v) -> {System.out.println(k + " : " + v.cantante + " | " + v.c.cancion);});
    }
    
}
